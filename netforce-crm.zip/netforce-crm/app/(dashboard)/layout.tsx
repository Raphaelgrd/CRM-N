import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="bg-surface-page flex h-screen overflow-hidden">
      <Sidebar />
      <main className="flex flex-1 flex-col overflow-hidden lg:ml-0">
        <Header />
        <div className="flex-1 overflow-y-auto">
          <div className="h-full">{children}</div>
        </div>
      </main>
    </div>
  );
}
